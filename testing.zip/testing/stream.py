import streamlit as st
from audiorecorder import audiorecorder
import tempfile
import speech_recognition as sr
import subprocess
import sys
from io import BytesIO
import os

st.title("SpeakTest")

audio = audiorecorder("Click to record", "Recording...")

if len(audio) > 0:
    # Convert AudioSegment to bytes for streamlit playback
    buffer = BytesIO()
    audio.export(buffer, format="wav")
    st.audio(buffer.getvalue(), format="audio/wav")

    # Save audio to a temp file
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        audio.export(f.name, format="wav")
        audio_path = f.name

    # Recognize speech from audio file
    recognizer = sr.Recognizer()
    with sr.AudioFile(audio_path) as source:
        audio_data = recognizer.record(source)
        try:
            text = recognizer.recognize_google(audio_data)
            st.success(f"Recognized: {text}")

            # Call swag.py as subprocess, passing text as argument
            result = subprocess.run(
                [sys.executable, "swagwithstream.py", text],
                capture_output=True,
                text=True,
                encoding="utf-8",
                check=True,
                cwd="D:/Code/testing",
                env={**os.environ, "pythonioencoding": "utf-8"}
            )
            if result.returncode == 0:
              st.code(result.stdout)
            else:
             st.error(f"Script error:\n{result.stderr}")
        except Exception as e:
            st.error(f"Speech recognition failed: {e}")
