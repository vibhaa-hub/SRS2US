# Streamlit UI for text input for sitewithstream.py
# Calling from unifiedstream.py so adding the render function here
def render():
 import streamlit as st
 import subprocess
 import sys
 import os

 st.title("Site Validator")

 task_input = st.text_area("Enter Task Instructions:", height=300)

 if st.button("Run Validation"):
    if task_input.strip():
        try:
            result = subprocess.run(
                [sys.executable, "sitewithstream.py", task_input],
                capture_output=True,
                text=True,
                encoding="utf-8",
                check=True,
                cwd="D:/Code/testing",  
                env={**os.environ, "pythonioencoding": "utf-8"}
            )

            if result.returncode == 0:
                st.success("Validation completed successfully!")
                st.code(result.stdout)
            else:
                st.error("Validation script returned error.")
                st.code(result.stderr)
        except Exception as e:
            st.error(f"Failed to run validation script: {e}")
    else:
        st.warning("Please enter a task before running.")
