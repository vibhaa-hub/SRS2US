#Swagger testing with voice
from langchain_google_genai import ChatGoogleGenerativeAI
from browser_use import Agent
from dotenv import load_dotenv
import os
import speech_recognition as sr
import logging

# Load environment variables
load_dotenv()
os.environ["GOOGLE_API_KEY"] = "AIzaSyBC_TAoSPKWHDsqKDcWR8S2ai9tITCyHHA"

# Configure logging
logging.basicConfig(filename=r'd:\Code\testing\output.log', level=logging.INFO, format='%(asctime)s - %(message)s')

def get_voice_input():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("Please describe the automation task...")
        audio = recognizer.listen(source, timeout=10, phrase_time_limit=100)

    try:
        text = recognizer.recognize_google(audio)
        print("You said:", text)
        return text
    except sr.UnknownValueError:
        print("Could not understand the audio.")
    except sr.RequestError as e:
        print("Could not request results; {0}".format(e))
    return None

async def main():
    # Get user voice input
    user_story = get_voice_input()
    if not user_story:
        return

    # Initialize Gemini model from LangChain wrapper
    llm = ChatGoogleGenerativeAI(model='gemini-2.0-flash-exp')

    # Create the Browser Use agent with the voice input task
    agent = Agent(task=user_story, llm=llm)

    # Run the agent
    result = await agent.run()

    # Log the result to the file
    logging.info("Generated Browser Use Automation Script:\n%s", result)

    # Also print the result to the console
    print("Generated Browser Use Automation Script:\n")
    print(result)

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
