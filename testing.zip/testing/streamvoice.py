# # streamlit UI for voice input for file swagwithstream.py
# import streamlit as st
# from audiorecorder import audiorecorder
# import tempfile
# import speech_recognition as sr
# import subprocess
# import sys
# from io import BytesIO
# import os

# st.title("SpeakTest")

# audio = audiorecorder("Click to record", "Recording...")

# if len(audio) > 0:
#     # Convert AudioSegment to bytes for streamlit playback
#     buffer = BytesIO()
#     audio.export(buffer, format="wav")
#     st.audio(buffer.getvalue(), format="audio/wav")

#     # Save audio to a temp file
#     with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
#         audio.export(f.name, format="wav")
#         audio_path = f.name

#     # Recognize speech from audio file
#     recognizer = sr.Recognizer()
#     with sr.AudioFile(audio_path) as source:
#         audio_data = recognizer.record(source)
#         try:
#             text = recognizer.recognize_google(audio_data)
#             st.success(f"Recognized: {text}")

#             # Call swagwithstream.py as subprocess, passing text as argument
#             result = subprocess.run(
#                 [sys.executable, "swagwithstream.py", text],
#                 capture_output=True,
#                 text=True,
#                 encoding="utf-8",
#                 check=True,
#                 cwd="D:/Code/testing",
#                 env={**os.environ, "pythonioencoding": "utf-8"}
#             )
#             if result.returncode == 0:
#               st.code(result.stdout)
#             else:
#              st.error(f"Script error:\n{result.stderr}")
#         except Exception as e:
#             st.error(f"Speech recognition failed: {e}")

##############################################################################################################################
# With editable text area and submit button
# import streamlit as st
# from audiorecorder import audiorecorder
# import tempfile
# import speech_recognition as sr
# import subprocess
# import sys
# from io import BytesIO
# import os

# st.title("SpeakTest")

# audio = audiorecorder("Click to record", "Recording...")

# if len(audio) > 0:
#     # Convert AudioSegment to bytes for streamlit playback
#     buffer = BytesIO()
#     audio.export(buffer, format="wav")
#     st.audio(buffer.getvalue(), format="audio/wav")

#     # Save audio to a temp file
#     with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
#         audio.export(f.name, format="wav")
#         audio_path = f.name

#     # Recognize speech from audio file
#     recognizer = sr.Recognizer()
#     with sr.AudioFile(audio_path) as source:
#         audio_data = recognizer.record(source)
#         try:
#             text = recognizer.recognize_google(audio_data)
#             st.success("Speech recognition successful")
#         except Exception as e:
#             st.error(f"Speech recognition failed: {e}")
#             text = ""  # Default to empty if failed

#     # Allow user to edit or confirm the recognized text
#     editable_text = st.text_area("Edit or enter the text below:", value=text, height=100)

#     if st.button("Submit"):
#         try:
#             result = subprocess.run(
#                 [sys.executable, "swagwithstream.py", editable_text],
#                 capture_output=True,
#                 text=True,
#                 encoding="utf-8",
#                 check=True,
#                 cwd="D:/Code/testing",
#                 env={**os.environ, "pythonioencoding": "utf-8"}
#             )
#             if result.returncode == 0:
#                 st.code(result.stdout)
#             else:
#                 st.error(f"Script error:\n{result.stderr}")
#         except Exception as ex:
#             st.error(f"Failed to run script: {ex}")
##############################################################################################################################
# Calling from unifiedstream.py so adding the render function here
def render():
    import streamlit as st
    from audiorecorder import audiorecorder
    import tempfile
    import speech_recognition as sr
    import subprocess
    import sys
    from io import BytesIO
    import os

    st.title("SpeakTest")

    audio = audiorecorder("Click to record", "Recording...")

    if len(audio) > 0:
        # Convert AudioSegment to bytes for streamlit playback
        buffer = BytesIO()
        audio.export(buffer, format="wav")
        st.audio(buffer.getvalue(), format="audio/wav")

        # Save audio to a temp file
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            audio.export(f.name, format="wav")
            audio_path = f.name

        # Recognize speech from audio file
        recognizer = sr.Recognizer()
        with sr.AudioFile(audio_path) as source:
            audio_data = recognizer.record(source)
            try:
                text = recognizer.recognize_google(audio_data)
                st.success("Speech recognition successful")
            except Exception as e:
                st.error(f"Speech recognition failed: {e}")
                text = ""  # Default to empty if failed

        # Allow user to edit or confirm the recognized text
        editable_text = st.text_area("Edit or enter the text below:", value=text, height=100)

        if st.button("Submit"):
            try:
                result = subprocess.run(
                    [sys.executable, "swagwithstream.py", editable_text],
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    check=True,
                    cwd="D:/Code/testing",
                    env={**os.environ, "pythonioencoding": "utf-8"}
                )
                if result.returncode == 0:
                    st.code(result.stdout)
                else:
                    st.error(f"Script error:\n{result.stderr}")
            except Exception as ex:
                st.error(f"Failed to run script: {ex}")
            
