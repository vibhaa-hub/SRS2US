import os
from datetime import datetime
import streamlit as st
from langchain.prompts import PromptTemplate
from langchain_community.vectorstores import FAISS
from langchain_ollama import OllamaLLM, OllamaEmbeddings
from langchain.schema import Document
from langchain_google_genai import ChatGoogleGenerativeAI

os.environ["GOOGLE_API_KEY"] = "AIzaSyBC_TAoSPKWHDsqKDcWR8S2ai9tITCyHHA"
model = ChatGoogleGenerativeAI(model="gemini-1.5-flash")

def load_prompt(path):
    with open(path, 'r', encoding='utf-8') as file:
        return file.read()

def generate_raw_text(requirement, prompt_template_path):
    template = load_prompt(prompt_template_path)
    prompt = PromptTemplate(input_variables=["requirement"], template=template)
    chain = prompt | model
    return chain.invoke(requirement).content

def generate_user_stories_from_raw_text(raw_text, prompt_template_path):
    template = load_prompt(prompt_template_path)
    prompt = PromptTemplate(input_variables=["raw_text"], template=template)
    chain = prompt | model
    return chain.invoke(raw_text).content

def extract_requirements_from_docx(file_path):
    from docx import Document as dox
    document = dox(file_path)
    return ["\n".join([para.text.strip() for para in document.paragraphs if para.text.strip()])]

def extract_requirements_from_markdown(file_path):
    text = file_path.read().decode("utf-8")
    return [text]

def create_faiss_index(requirements, embedding):
    docs = [Document(page_content=req) for req in requirements]
    return FAISS.from_documents(docs, embedding)

def retrieve_requirement(query, vector_store, k=1):
    docs = vector_store.similarity_search(query, k=k)
    return docs[0].page_content if docs else None

def process_srs_and_generate_stories(file_obj, doc_type, format_type, output_directory):
    os.makedirs(output_directory, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = os.path.join(output_directory, f"user_stories_{timestamp}.txt")

    prompt_first_path = "prompts/prompt_first.txt"
    prompt_second_path = "prompts/prompt_gherkin.txt" if format_type == "Gherkin" else "prompts/prompt_normal.txt"

    with open(output_path, 'w', encoding='utf-8') as out_file:
        if doc_type == "DOCX":
            requirements = extract_requirements_from_docx(file_obj)
        else:
            requirements = extract_requirements_from_markdown(file_obj)

        embedding = OllamaEmbeddings(model="nomic-embed-text")
        faiss_index = create_faiss_index(requirements, embedding)

        for i, req in enumerate(requirements):
            relevant = retrieve_requirement(req, faiss_index)
            raw_text = generate_raw_text(relevant, prompt_first_path)
            user_stories = generate_user_stories_from_raw_text(raw_text, prompt_second_path)

            out_file.write(f"Chunk {i}:\nRaw Text:\n{raw_text}\nUser Stories:\n{user_stories}\n{'-'*50}\n")

    return output_path

st.set_page_config(page_title="SRS to User Stories Generator", page_icon="📄", layout="wide")

with st.sidebar:
    st.header("SRS to User Stories Generator")
    doc_type = st.selectbox("Select Document Type", options=["DOCX", "Markdown"])
    file_ext = "docx" if doc_type == "DOCX" else "md"
    format_type = st.selectbox("Select Output Format", options=["Gherkin", "Normal"])
    st.subheader(f"Upload your SRS document ({file_ext})")

st.title("SRS to User Stories Generator 📄")
st.markdown("Upload an SRS document to generate **user stories** and **acceptance criteria**.")

uploaded_file = st.file_uploader("Choose a file", type=["docx", "md"], label_visibility="collapsed")

if uploaded_file:
    st.success("File uploaded successfully! 🎉")
    output_directory = st.text_input("Output Directory", "D:/Code/OUTPUT", help="Where to save the output file")

    if st.button("Generate User Stories 🔄"):
        with st.spinner("Processing... Please wait."):
            progress = st.progress(0)
            output_path = process_srs_and_generate_stories(uploaded_file, doc_type, format_type, output_directory)

            for i in range(100): progress.progress(i + 1)
            st.success("User stories generated successfully! 🎉")

            st.markdown("#### Download the generated user stories:")
            st.download_button(
                label="📥 Download User Stories",
                data=open(output_path, 'rb'),
                file_name=os.path.basename(output_path),
                mime="text/plain",
                use_container_width=True
            )
else:
    st.warning("Please upload an SRS document to get started.")
